"""Just test with lambda functions, so here if we need to deploy cloud functions,
so need to create a requirements.txt by ourself, also we need to download the packages manually by:
`python -m pip install -m requirements.txt -t .` to download needed packages local, 
then we need to zip them into a zip file and upload it into functions.
"""
import json

import requests
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression


def lambda_handler(event, context):
    # TODO implement
    d = requests.get("https://www.baidu.com")
    x, y = load_iris(return_X_y=True)
    lr = LogisticRegression()

    lr.fit(x,y)
    score = lr.score(x, y)
    return {"code": d.code, "Model_score": score}
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
