# -*- coding:utf-8 -*-
"""


@author: Guangqiang.lu
"""
def hello_world(request):
    if "message" in request.args:
        return request.args.get("message") + " , so good!"
    else:
        return f"not so good..."